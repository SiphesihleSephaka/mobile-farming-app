package com.example.applicationfarming;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView;

public class crops extends AppCompatActivity {
    String[] crop = {"Tomato R10 each", "Onion R10 each","Banana R5 each","Corn R20 each"};

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.crops);

        Spinner spin= (Spinner)findViewById(R.id.spinV2);

        ArrayAdapter<String> aa=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,crop);

        spin.setAdapter(aa);

        final int[] count = {0};
        final double[] itemPrice = {0.0}; // Stores the price per item (e.g., Tomato R10 each)

        TextView textView27 = findViewById(R.id.textView27);
        final TextView textView29 = findViewById(R.id.textView29); // Added textView29 for total price

        Button button8 = findViewById(R.id.button8);
        Button button10 = findViewById(R.id.button10);
        Button button9= findViewById(R.id.button9);

        // Set the initial item price based on the selected item in the spinner
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedItem = crop[position];
                String[] parts = selectedItem.split(" ");
                if (parts.length >= 2) {
                    try {
                        itemPrice[0] = Double.parseDouble(parts[1]); // Extract and parse the price
                        updateTotalPrice(count[0], itemPrice[0], textView29);
                    } catch (NumberFormatException e) {
                        // Handle parsing error, if any
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing here
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Increase the count and update the TextView
                count[0]++;
                textView27.setText(String.valueOf(count[0]));
                updateTotalPrice(count[0], itemPrice[0], textView29);
            }
        });

        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Decrease the count (if count is greater than 0) and update the TextView
                if (count[0] > 0) {
                    count[0]--;
                    textView27.setText(String.valueOf(count[0]));
                    updateTotalPrice(count[0], itemPrice[0], textView29);
                }
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Calculate the total price
                double totalPrice = count[0] * itemPrice[0]; // Assuming count and itemPrice are declared in your code

                // Create an intent to navigate to the payment class
                Intent intent = new Intent(crops.this, payment.class);

                // Pass the total price as an extra to the intent
                intent.putExtra("totalPrice", totalPrice);

                // Start the payment activity
                startActivity(intent);
            }
        });
    }

    // Function to update the total price
    private void updateTotalPrice(int quantity, double pricePerItem, TextView textView) {
        double totalPrice = quantity * pricePerItem;
        textView.setText("Total Price: R" + totalPrice);
    }
}
