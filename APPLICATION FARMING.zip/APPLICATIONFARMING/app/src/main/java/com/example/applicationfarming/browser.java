package com.example.applicationfarming;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
public class browser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.browse);

        Button livestock = findViewById(R.id.livestock);
        Button crops = findViewById(R.id.crops);

        livestock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(browser.this, livestock.class);
                startActivity(intent);
            }
        });

        crops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(browser.this, crops.class);
                startActivity(intent);
            }
        });
    }
}
