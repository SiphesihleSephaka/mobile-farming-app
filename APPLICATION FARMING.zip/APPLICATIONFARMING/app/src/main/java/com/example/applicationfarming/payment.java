package com.example.applicationfarming;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class payment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment);

        Button button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(payment.this, confirmation.class);
                startActivity(intent);
            }
        });

        TextView textView15 = findViewById(R.id.textView15); // Replace with your TextView ID

        // Retrieve the total price from the intent
        Intent intent = getIntent();
        double totalPrice = intent.getDoubleExtra("totalPrice", 0.0); // 0.0 is the default value if the key is not found

        // Set the total price to textView15
        textView15.setText("Total Price: R" + totalPrice);

    }
}
