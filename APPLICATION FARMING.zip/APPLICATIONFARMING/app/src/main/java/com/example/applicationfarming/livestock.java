package com.example.applicationfarming;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

public class livestock extends AppCompatActivity {

    String[] animals = {"Cow R3500", "Sheep R2000","Chicken R500","Goat R3000"};

    private TextView textView24;
    private TextView textView25;
    private int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.livestock);

        Spinner spin = findViewById(R.id.spinV);

        ArrayAdapter<String> aa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, animals);

        spin.setAdapter(aa);

        textView24 = findViewById(R.id.textView24);
        textView25 = findViewById(R.id.textView25);

        Button button5 = findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(livestock.this, payment.class);
                // Pass the total price to the payment class
                double totalPrice = calculateTotalPrice();
                intent.putExtra("totalPrice", totalPrice);
                startActivity(intent);
            }
        });

        Button button6 = findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Increase the count and update textView25
                count++;
                textView25.setText(String.valueOf(count));
                // Recalculate and update the total price
                updateTotalPrice();
            }
        });

        Button button7 = findViewById(R.id.button7);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Decrease the count (if count is greater than 0) and update textView25
                if (count > 0) {
                    count--;
                    textView25.setText(String.valueOf(count));
                    // Recalculate and update the total price
                    updateTotalPrice();
                }
            }
        });
    }

    // Calculate and update the total price
    private void updateTotalPrice() {
        double unitPrice = 0.0; // Replace with the actual unit price
        double totalPrice = count * unitPrice;
        textView24.setText("Total Price: R" + totalPrice);
    }

    // Calculate the total price based on count and unit price
    private double calculateTotalPrice() {
        double unitPrice = 0.0; // Replace with the actual unit price
        return count * unitPrice;
    }
}
